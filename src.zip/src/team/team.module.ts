import { Module } from '@nestjs/common';
import { TeamController } from './team.controller';
import { TeamService } from './team.service';
import {MatchService} from '../match/match.service'
import { TypeOrmModule } from '@nestjs/typeorm';
import { Team } from 'src/entities/team.entity';
import {Match} from '../entities/match.entity'

@Module({
  imports: [TypeOrmModule.forFeature([Team]),TypeOrmModule.forFeature([Match])],
  controllers: [TeamController],
  providers: [TeamService, MatchService]
})
export class TeamModule {}
