import { Controller, Get, Post, Res, Body, Delete } from '@nestjs/common';
import { TeamService } from './team.service';
import { MatchService } from '../match/match.service';
import { Team } from 'src/entities/team.entity';

@Controller('teams')
export class TeamController {
  constructor(
    private teamService: TeamService,
    private matchService: MatchService,
  ) {}

  @Get()
  async getTeams() {
    return this.teamService.findAll();
  }

  @Post()
  async addTeam(@Res() res, @Body() team: Team) {
    this.teamService
      .create(team)
      .then(data => {
        return res.status(201).json({
          message: 'Team added!',
        });
      })
      .catch(err => {
        console.log(err);
        return res.status(500).json({
          message: 'Create failed!',
        });
      });
  }

  @Post('list')
  async addListTeam(@Res() res, @Body() teams: Team) {
    this.teamService
      .create(teams)
      .then(data => {
        var d = JSON.stringify(data);
        this.matchService.createMatch(data).then(() => {
          console.log('match created!');
        });
        return res.status(201).json({
          message: 'Teams added!',
        });
      })
      .catch(err => {
        console.log(err);
        return res.status(500).json({
          message: 'Create failed!',
        });
      });
  }

  @Delete()
  async delete(@Res() res) {
    this.teamService
      .remove()
      .then(() => {
        return res.status(200).json({
          message: 'League deleted!',
        });
      })
      .catch(err => {
        console.log(err);
        return res.status(500).json({
          message: 'Delete league failed!',
        });
      });
  }

  @Post('update')
  async reCreate(@Res() res, @Body() teams: Team) {
    this.teamService
      .reCreate(teams)
      .then(() => {
        return res.status(201).json({
          message: 'League updated!',
        });
      })
      .catch(err => {
        console.log(err);
        return res.status(500).json({
          message: 'Update league failed!',
        });
      });
  }
}
