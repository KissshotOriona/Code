import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Team } from 'src/entities/team.entity';
import { UpdateResult, DeleteResult } from 'typeorm';
const ObjectId = require('mongodb').ObjectId;
@Injectable()
export class TeamService {
  constructor(
    @InjectRepository(Team)
    private teamRepository: Repository<Team>,
  ) {}

  async findAll(): Promise<Team[]> {
    return await this.teamRepository.find();
  }

  async create(team: Team): Promise<Team> {
    return await this.teamRepository.save(team);
  }

  async insertList(team: Team[]): Promise<Team[]> {
    return await this.teamRepository.save(team);
  }

  async update(team: Team): Promise<UpdateResult> {
    return await this.teamRepository.update(team.id, team);
  }

  async delete(id): Promise<DeleteResult> {
    return await this.teamRepository.delete(id);
  }
  async remove(): Promise<any> {
    return await this.teamRepository.clear();
  }
  async reCreate(teams: Team): Promise<any> {
    await this.teamRepository.clear();
    return await this.teamRepository.save(teams);
  }

  async updateMatchRes(match): Promise<any> {
    const all = await this.findAll();
    var team1 = all.filter(d => {
      return d.id == match.ids.id1;
    });
    var team2 = all.filter(d => {
      return d.id == match.ids.id2;
    });
    if (match.goal.g1 > match.goal.g2) {
      team1.map(t=>{
        t.w = t.w+1;
        t.pts= t.pts + 3;
      })
      team2.map(t=>{
        t.l = t.l +1;
      })
    } else {
      if (match.goal.g1 == match.goal.g2) {
        team1.map(t=>{
          t.d = t.d+1;
          t.pts= t.pts + 1;
        })
        team2.map(t=>{
          t.d = t.d+1;
          t.pts= t.pts + 1;
        })
      } else {
        team2.map(t=>{
          t.w = t.w+1;
          t.pts= t.pts + 3;
        })
        team1.map(t=>{
          t.l = t.l +1;
        })
      }
    }
    this.update(team1[0]);
    this.update(team2[0]);
  }
}
