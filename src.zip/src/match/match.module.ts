import { Module } from '@nestjs/common';
import { MatchService } from './match.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Match } from '../entities/match.entity';
import { Team } from '../entities/team.entity';
import { MatchController } from './match.controller';
import { TeamService } from 'src/team/team.service';

@Module({
  imports: [TypeOrmModule.forFeature([Match]), TypeOrmModule.forFeature([Team])],
  providers: [MatchService, TeamService],
  controllers: [MatchController],
})
export class MatchModule {}
