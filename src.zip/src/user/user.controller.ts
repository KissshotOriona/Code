import { Controller, Post, Body, Res, Next } from '@nestjs/common';
import { UserService } from './user.service';
import { User } from 'src/entities/user.entity';
import { gvars } from 'src/ultils';
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
@Controller('user')
export class UserController {
  constructor(private userService: UserService) {}

  @Post('regis')
  async signUp(@Res() res, @Body() user: User) {
    this.userService.findByEmail(user.email).then(result => {
      if (result) {
        return res.status(409).json({ message: 'Email existed!' });
      } else {
        bcrypt.hash(user.password, 10, (err, hash) => {
          if (err) {
            return res.status(500).json({ error: err });
          } else {
            user.password = hash;
            this.userService
              .signUp(user)
              .then(result => {
                console.log(result);
                res.status(201).json({ message: 'User created!' });
              })
              .catch(err => {
                console.log(err);
                res.status(500).json(err);
              });
          }
        });
      }
    });
  }

  @Post('login')
  async login(@Res() res, @Body() user: User) {
    this.userService
      .findByEmail(user.email)
      .then(data => {
        if (!data) {
          return res.status(401).json({
            message: 'Auth failed!',
          });
        } else {
          bcrypt.compare(user.password, data.password, (err, result) => {
            if (err) {
              return res.status(401).json({
                message: 'Auth failed!',
              });
            }
            if (result) {
              const token = jwt.sign(
                {
                  email: data.email,
                  userId: data.id,
                },
                gvars.JWT_KEY,
                {
                  expiresIn: '1h',
                },

              );
              return res.status(200).json({
                message: 'Auth successful!',
                token: token
              });
            } else {
              return res.status(401).json({
                message: 'Auth failed!',
              });
            }
          });
        }
      })
      .catch(err => {
        console.log(err);
        res.status(500).json(err);
      });
  }
}
