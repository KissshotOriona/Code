import { Entity, ObjectID, ObjectIdColumn, Column } from 'typeorm';

@Entity()
export class Match {
  @ObjectIdColumn()
  id: ObjectID;

  @Column()
  ids: { id1: String; id2: String };

  @Column()
  team: { t1: String; t2: String };

  @Column()
  goal: { g1: number; g2: number };

  @Column()
  card: { y1: number; y2: number; r1: number; r2: number };

  @Column()
  date: String;

  @Column()
  time: String;
}
