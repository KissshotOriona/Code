import {Entity, ObjectID, ObjectIdColumn, Column, CreateDateColumn} from "typeorm";

@Entity()
export class Team {
    
    @ObjectIdColumn()
    id: ObjectID;
    
    @Column()
    stt: string;
    
    @Column()
    name: string;

    @Column()
    brief: string;

    @Column()
    mp: number;

    @Column()
    w: number;

    @Column()
    d: number;

    @Column()
    l: number;

    @Column()
    pts: number;

    @CreateDateColumn({ type: 'timestamp' })
    createdDate: Date
}