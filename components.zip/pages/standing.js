import Root from '../components/root'
import React, { Component } from 'react';
import StandingTable from '../components/standingTable/standingTable'

class Standing extends Component {
    state = {  }
    render() { 
        return ( <Root><StandingTable></StandingTable></Root> );
    }
}

export default Standing;