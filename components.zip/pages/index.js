import React, { Component } from "react";
import TeamForm from "../components/teamForm/teamForm";
import { TeamTable } from "../components/teamTable/teamTable";
import Root from "../components/root"

export default class App extends Component {
  constructor(props) {
    super(props)
  }
  static async getInitialProps() {
    const res = await fetch(process.env.API_HOST + "teams");
    const data = await res.json();
    return {
      teams: data
    };
  }
  state = { displayMode: "form" };
  display = () => {
    if (!this.props.teams.length) {
      return <TeamForm/>;
    } else {
      return <TeamTable/>;
    }
  };
  
  sidemenuClick = value => {
    this.setState({ displayMode: value });
  };
  render() {
    return (
      <Root>
        {this.display()}
      </Root>     
    );
  }
}
