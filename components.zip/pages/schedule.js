import Root from "../components/root";
import React, { Component } from "react";
import ScheduleTable from "../components/scheduleTable/scheduleTable";

class Schedule extends Component {
  state = {};
  render() {
    return <Root>
        <ScheduleTable></ScheduleTable>
    </Root>;
  }
}

export default Schedule;
