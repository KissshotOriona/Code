import { PageHeader } from "./header/header";
import {SideMenu} from './sideMenu/sideMenu'
import {Layout, Col, Row} from 'antd'
const { Header } = Layout;
export default function Root(props) {
  return (
    <div>
      <Layout>
        <Header style={{ background: "#58a700", padding: 0 }}>
          <PageHeader />
        </Header>
        <Layout>
          <Row type="flex" gutter={8} style={{ width: "100%" }}>
            <Col
              xs={24}
              sm={8}
              md={6}
              lg={4}
              style={{ borderBottom: "1px solid #bfbfbf" }}
            >
              <SideMenu />
            </Col>
            <Col
              xs={24}
              sm={16}
              md={18}
              lg={20}
              style={{
                paddingLeft: "10px",
                borderLeft: "1px solid #bfbfbf",
                borderBottom: "1px solid #bfbfbf",
                textAlign: "center",
                paddingBottom: "10px"
              }}
            >
              {props.children}
            </Col>
          </Row>
        </Layout>
      </Layout>
    </div>
  );
}
