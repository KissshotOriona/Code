import React, { Component } from "react";
import { Form, InputNumber, Layout, Button, Input } from "antd";
import "./teamForm.css";
import SubForm from "./subForm";
class NoTForm extends Component {
  state = {
    teams: 0,
    inputs: [],
    tableProps: { layout: "inline" },
    saveable: false
  };
  valueChange = val => {
    this.setState({
      teams: val
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.setState({ inputs: <SubForm teams={this.state.teams} /> });
      } else {
        console.log("Received values of form: ", values);
      }
    });
  };

  transformOnResize() {
    if (window.innerWidth < 575) {
      this.setState({
        tableProps: { layout: "horizontal" }
      });
    } else {
      this.setState({
        tableProps: { layout: "inline" }
      });
    }
  }

  componentDidMount() {
    this.transformOnResize();
    window.addEventListener("resize", this.transformOnResize.bind(this));
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <Layout>
        <Form
          {...this.state.tableProps}
          style={{ margin: "20px 0" }}
          onSubmit={this.handleSubmit}
        >
          <Form.Item label="Number of teams">
            {getFieldDecorator("number", {
              rules: [
                {
                  required: true,
                  type: "number",
                  message: "Please input number!"
                }
              ]
            })(<InputNumber min={2} max={64} onChange={this.valueChange} />)}
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Create League
            </Button>
          </Form.Item>
        </Form>
        {this.state.inputs}
      </Layout>
    );
  }
}
const TeamForm = Form.create()(NoTForm);
export default TeamForm;
