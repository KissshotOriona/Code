import { Table, Form, Input, Row, Col, InputNumber, Button } from "antd";
import React, { Component } from "react";
import fetch from "isomorphic-unfetch";
import MatchForm from './matchForm'

const columns = [
  { title: "#", dataIndex: "stt", key: "name", align: "center" },
  { title: "Team 1", dataIndex: "team.t1", key: "t1", align: "center" },
  { title: "Result", dataIndex: "res", key: "res", align: "center" },
  { title: "Team 2", dataIndex: "team.t2", key: "t2", align: "center" },
  { title: "Date", dataIndex: "date", key: "date", align: "center" },
  { title: "Time", dataIndex: "time", key: "time", align: "center" }
];

class ScheduleTable extends Component {
  state = {
    data: []
  };
  constructor(props) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  async fetchData() {
    var res = await fetch(process.env.API_HOST + "match");
    var data = await res.json();
    return data;
  }
  componentDidMount() {
    this.fetchData()
      .then(data => {
        data.map((e, index) => {
          e.stt = index + 1;
          e.res = e.goal.g1 + " - " + e.goal.g2;
        });
        this.setState({ data: data });
      })
      .catch(err => console.log(err));
  }
  handleSubmit(e) {
    e.preventDefault();
    var keyId = e.target.getAttribute("keyId");
    var match = this.state.data.filter(d => {return d.id == keyId});
    
    fetch(process.env.API_HOST + "match", {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(match)
    }).then(res => {
      if (res.status == 200) {
        notification.open({
          message: "Match info updated",
          description: "Match info have been saved!",
          icon: <Icon type="smile" style={{ color: "#108ee9" }} />
        });
        Router.push("/")
      } else {
        notification.open({
          message: "Error occured! Status " + res.status,
          description: "There was some problem when update match!",
          icon: <Icon type="frown" style={{ color: "#108ee9" }} />
        });
      }
    });
  }
  render() {
    return (
      <div>
        <Table
          bordered
          columns={columns}
          expandedRowRender={record => (
            <MatchForm data={this.state.data} record={record}></MatchForm>
          )}
          dataSource={this.state.data}
        />
        ,
      </div>
    );
  }
}
export default ScheduleTable;
