import React, { Component } from "react";
import { Form, Row, Col, InputNumber, Button, notification, Icon } from "antd";
class matchForm extends Component {
  constructor(props) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit(e) {
    e.preventDefault();
    var keyId = e.target.getAttribute("keyId");
    var match = this.props.data.filter(d => {
      return d.id == keyId;
    });

    this.props.form.validateFields((err, values) => {
      if (!err) {
        match[0].goal.g1 = values["1"];
        match[0].goal.g2 = values["4"];
        match[0].card.r1 = values["2"];
        match[0].card.r2 = values["5"];
        match[0].card.y1 = values["3"];
        match[0].card.y2 = values["6"];
        
      } else {
        console.log(err);
      0}
    });

    fetch(process.env.API_HOST + "match", {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(match[0])
    }).then(res => {
      if (res.status == 200) {
        notification.open({
          message: "Match info updated",
          description: "Match info have been saved!",
          icon: <Icon type="smile" style={{ color: "#108ee9" }} />
        });
      } else {
        notification.open({
          message: "Error occured! Status " + res.status,
          description: "There was some problem when update match!",
          icon: <Icon type="frown" style={{ color: "#108ee9" }} />
        });
      }
    });
  }
  render() {
    const { getFieldDecorator } = this.props.form;
    const record = this.props.record;
    return (
      <Form keyId={record.id} onSubmit={this.handleSubmit}>
        <Row gutter={32}>
          <Col
            sm={6}
            offset={6}
            style={{ border: "1px solid #eee", paddingTop: "10px" }}
          >
            <h4 style={{ textAlign: "center" }}>{record.team.t1}</h4>
            <Form.Item label="Goal">
              {getFieldDecorator("1", {
                initialValue: record.goal.g1,
                rules: [{ required: true, message: "Please input number!" }]
              })(<InputNumber style={{ width: "100%" }} />)}
            </Form.Item>
            <Form.Item label="Red card">
              {getFieldDecorator("2", {
                initialValue: record.card.r1,
                rules: [{ required: true, message: "Please input number!" }]
              })(<InputNumber style={{ width: "100%" }} />)}
            </Form.Item>
            <Form.Item label="Yellow card">
              {getFieldDecorator("3", {
                initialValue: record.card.y1,
                rules: [{ required: true, message: "Please input number!" }]
              })(<InputNumber style={{ width: "100%" }} />)}
            </Form.Item>
          </Col>
          <Col sm={6} style={{ border: "1px solid #eee", paddingTop: "10px" }}>
            <h4 style={{ textAlign: "center" }}>{record.team.t2}</h4>
            <Form.Item label="Goal">
              {getFieldDecorator("4", {
                initialValue: record.goal.g2,
                rules: [{ required: true, message: "Please input number!" }]
              })(<InputNumber style={{ width: "100%" }} />)}
            </Form.Item>
            <Form.Item label="Red card">
              {getFieldDecorator("5", {
                initialValue: record.card.r2,
                rules: [{ required: true, message: "Please input number!" }]
              })(<InputNumber style={{ width: "100%" }} />)}
            </Form.Item>
            <Form.Item label="Yellow Card">
              {getFieldDecorator("6", {
                initialValue: record.card.y2,
                rules: [{ required: true, message: "Please input number!" }]
              })(<InputNumber style={{ width: "100%" }} />)}
            </Form.Item>
          </Col>
        </Row>
        <Form.Item
          wrapperCol={{ xs: { span: 24 } }}
          style={{ textAlign: "center" }}
        >
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    );
  }
}
const MatchForm = Form.create()(matchForm);
export default MatchForm;
