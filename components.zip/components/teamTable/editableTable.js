import React, { Component } from "react";
import {
  Table,
  Input,
  Button,
  Popconfirm,
  Form,
  notification,
  Icon,
  Modal
} from "antd";
import Router from "next/router";
import fetch from "isomorphic-unfetch";

const FormItem = Form.Item;
const EditableContext = React.createContext();

class EditableCell extends React.Component {
  state = {
    editing: false
  };

  toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  save = e => {
    const { record, handleSave } = this.props;
    this.form.validateFields((error, values) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }
      this.toggleEdit();
      handleSave({ ...record, ...values });
    });
  };

  render() {
    const { editing } = this.state;
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <EditableContext.Consumer>
            {form => {
              this.form = form;
              return editing ? (
                <FormItem style={{ margin: 0 }}>
                  {form.getFieldDecorator(dataIndex, {
                    rules: [
                      {
                        required: true,
                        message: `${title} is required.`
                      }
                    ],
                    initialValue: record[dataIndex]
                  })(
                    <Input
                      ref={node => (this.input = node)}
                      onPressEnter={this.save}
                      onBlur={this.save}
                    />
                  )}
                </FormItem>
              ) : (
                <div
                  className="editable-cell-value-wrap"
                  style={{ paddingRight: 24 }}
                  onClick={this.toggleEdit}
                >
                  {restProps.children}
                </div>
              );
            }}
          </EditableContext.Consumer>
        ) : (
          restProps.children
        )}
      </td>
    );
  }
}

const EditableRow = ({ form, index, ...props }) => (
  <EditableContext.Provider value={form}>
    <tr {...props} />
  </EditableContext.Provider>
);
const EditableFormRow = Form.create()(EditableRow);

export class EditableTable extends Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "#",
        dataIndex: "stt",
        width: "5%"
      },
      {
        title: "Name",
        dataIndex: "name",
        width: "40%",
        editable: true
      },
      {
        title: "Brief name",
        dataIndex: "brief",
        editable: true
      },
      {
        title: "Operation",
        dataIndex: "operation",
        render: (text, record) =>
          this.state.dataSource.length >= 1 ? (
            <Popconfirm
              title="Sure to delete?"
              onConfirm={() => this.handleDelete(record.key)}
            >
              <a href="javascript:;">Delete</a>
            </Popconfirm>
          ) : null
      }
    ];

    this.state = {
      dataSource: [],
      count: 0,
      dataChange: false
    };
  }

  handleDelete = key => {
    const dataSource = [...this.state.dataSource];
    this.setState({
      dataSource: dataSource.filter(item => item.key !== key),
      dataChange: true
    });
  };

  handleAdd = () => {
    const { count, dataSource } = this.state;
    const newData = {
      key: count,
      name: `Team ${count}`,
      stt: parseInt(dataSource[dataSource.length - 1].stt) + 1,
      brief: `T${count}`
    };
    this.setState({
      dataSource: [...dataSource, newData],
      count: count + 1,
      dataChange: true,
      visible: false
    });
  };

  handleSave = row => {
    const newData = [...this.state.dataSource];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row
    });
    this.setState({ dataSource: newData });
  };

  submitData = () => {
    let data = this.state.dataSource;
    delete data["key"];
    fetch(process.env.API_HOST + "teams/update", {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    }).then(res => {
      if (res.status == 201) {
        notification.open({
          message: "Save change success",
          description: "New team list have been saved!",
          icon: <Icon type="smile" style={{ color: "#108ee9" }} />
        });
      } else {
        notification.open({
          message: "Error occured! Status " + res.status,
          description: "There was some problem when update team list!",
          icon: <Icon type="frown" style={{ color: "#108ee9" }} />
        });
      }
    });
  };
  async fetchData() {
    const res = await fetch(process.env.API_HOST + "teams");
    const data = await res.json();
    return data;
  }

  componentDidMount() {
    this.fetchData().then(data => {
      data.map(d => (d.key = d.stt - 1 + ""));
      this.setState({ dataSource: data, count: data.length });
    });
  }
  showModal = () => {
    this.setState({
      visible: true
    });
  };
  handleOk = e => {
    this.setState({
      visible: false
    });
    fetch(process.env.API_HOST + "teams", { method: "delete" })
      .then(res => {
        if (res.status == 200) {
          notification.open({
            message: "League is deleted",
            description: "You can create new league now!",
            icon: <Icon type="smile" style={{ color: "#108ee9" }} />
          });
          Router.push("/");
        } else {
          notification.open({
            message: "Error occured! Status " + res.status,
            description: "There was some problem when delete league!",
            icon: <Icon type="frown" style={{ color: "#108ee9" }} />
          });
        }
      })
      .catch(err => {
        console.log(err);
      });
  };

  handleCancel = e => {
    this.setState({
      visible: false
    });
  };
  render() {
    const components = {
      body: {
        row: EditableFormRow,
        cell: EditableCell
      }
    };
    const columns = this.columns.map(col => {
      if (!col.editable) {
        return col;
      }
      return {
        ...col,
        onCell: record => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleSave
        })
      };
    });

    return (
      <div>
        <Button
          onClick={this.handleAdd}
          type="primary"
          style={{ margin: "10px 0px" }}
        >
          Add new team
        </Button>
        <Button
          onClick={this.showModal}
          style={{
            margin: "10px 5px",
            background: "#dc3545",
            borderColor: "#dc3545",
            color:"white"
          }}
        >
          Delete league
        </Button>
        <Modal
          title="Delete Confirm"
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <p>Are you sure to delete this league?</p>
        </Modal>
        <Table
          components={components}
          rowClassName={() => "editable-row"}
          bordered
          dataSource={this.state.dataSource}
          columns={columns}
          pagination={{ defaultPageSize: 10 }}
        />
        {this.state.dataChange ? (
          <Button
            onClick={this.submitData}
            type="primary"
            style={{ background: "#28a745" }}
          >
            Save change
          </Button>
        ) : (
          ""
        )}
      </div>
    );
  }
}
