import React, { Component } from "react";
import { Table } from "antd";
import fetch from "isomorphic-unfetch";
class StandingTable extends Component {
  constructor(props) {
    super(props);
    this.data = [
      {
        stt: 1,
        name: "Manchester United",
        mp: 22,
        w: 20,
        d: 1,
        l: 1,
        pts: 61
      }
    ];
    this.columns = [
      {
        title: "#",
        dataIndex: "stt",
        width: "5%"
      },
      {
        title: "Name",
        dataIndex: "name",
        width: "40%"
      },
      {
        title: "MP",
        dataIndex: "mp",
        width: "5%"
      },
      {
        title: "W",
        dataIndex: "w",
        width: "5%"
      },
      {
        title: "D",
        dataIndex: "d",
        width: "5%"
      },
      {
        title: "L",
        dataIndex: "l",
        width: "5%"
      },
      {
        title: "Pts",
        dataIndex: "pts",
        width: "5%"
      }
    ];
  }
  async fetchData() {
    const res = await fetch(process.env.API_HOST + "teams");
    const data = await res.json();
    return data;
  }
  componentDidMount() {
    this.fetchData()
      .then(res => {
        res.map(d => (d.key = d.stt));
        this.setState({ data: res });
      })
      .catch(err => {
        console.log(err);
      });
  }
  state = { data: [] };
  render() {
    return (
      <div>
        <Table columns={this.columns} dataSource={this.state.data}/>
      </div>
    );
  }
}

export default StandingTable;
