import React, { Component } from "react";
import { Layout, Menu, Icon, Dropdown, message, Row, Col, Button } from "antd";
import "./header.css";
const { Header } = Layout;

export class PageHeader extends Component {
  state = {};

  render() {
    function handleButtonClick(e) {
      message.info("Click on left button.");
      console.log("click left button", e);
    }

    function handleMenuClick(e) {
      message.info("Click on menu item.");
      console.log("click", e);
    }

    const menu = (
      <Menu onClick={handleMenuClick}>
        <Menu.Item key="1">
          <Icon type="user" />
          Log out
        </Menu.Item>
        <Menu.Item key="2">
          <Icon type="info-circle" />
          Info
        </Menu.Item>
      </Menu>
    );
    return (
      <Layout>
        <Header style={{ position: "fixed", zIndex: 1, width: "100%", background: "#58a700"}}>
          <Row>
            <Col span={6}>
              <div className="logo">
                <Icon type="home" style={{fontSize: "20px", color: "white", cursor: "pointer"}}/>
              </div>
            </Col>
            <Col span={6} offset={12}>
              <div style={{ float: "right", marginRight: 20 }}>
                <Dropdown overlay={menu}>
                  <Button>
                    Option <Icon type="down" />
                  </Button>
                </Dropdown>
              </div>
            </Col>
          </Row>
        </Header>
      </Layout>
    );
  }
}
