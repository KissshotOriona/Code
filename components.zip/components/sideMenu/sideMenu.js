import React, { Component } from "react";
import { Menu, Icon } from "antd";
import Router from "next/router";
export class SideMenu extends Component {
  state = {
    selected: "1"
  };
  menuClick(e) {
    if (e.key == 1) {
      Router.push("/");
    } else {
      if (e.key == 2) {
        Router.push("/schedule");
      } else {
        Router.push("/standing");
      }
    }
  }
  
  getSelectItem() {
    if (typeof window !== "undefined") {
      var ref = window.location.href.split("/");
      var tab = ref[ref.length - 1];
      if (tab == "schedule") {
        return "2";
      } else {
        if (tab == "standing") {
          return "3";
        } else {
          return "1";
        }
      }
    }
  }
  render() {
    return (
      <Menu
        defaultSelectedKeys={[this.getSelectItem()]}
        defaultOpenKeys={["sub1"]}
        mode="inline"
        inlineCollapsed={this.state.collapsed}
      >
        <Menu.Item key="1" onClick={this.menuClick}>
          <Icon type="deployment-unit" />
          <span>League</span>
        </Menu.Item>
        <Menu.Item key="2" onClick={this.menuClick}>
          <Icon type="apartment" />
          <span>Match schedule</span>
        </Menu.Item>
        <Menu.Item key="3" onClick={this.menuClick}>
          <Icon type="trophy" />
          <span>Standing</span>
        </Menu.Item>
      </Menu>
    );
  }
}
